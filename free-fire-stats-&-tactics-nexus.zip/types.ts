
export interface DiamondBundle {
  id: string;
  amount: number;
  bonus?: number;
  price: number;
  icon: string;
}

export interface PaymentMethod {
  id: string;
  name: string;
  logo: string;
  fee: number;
}

export interface Weapon {
  name: string;
  type: string;
  damage: number;
  rateOfFire: number;
  range: number;
  image: string;
}

export interface Character {
  name: string;
  ability: string;
  description: string;
  image: string;
}
