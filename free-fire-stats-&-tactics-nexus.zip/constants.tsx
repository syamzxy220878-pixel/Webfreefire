
import { DiamondBundle, PaymentMethod, Weapon, Character } from './types';

export const DIAMOND_BUNDLES: DiamondBundle[] = [
  { id: 'd1', amount: 5, price: 1000, icon: '💎' },
  { id: 'd2', amount: 50, bonus: 5, price: 8000, icon: '💎' },
  { id: 'd3', amount: 70, bonus: 10, price: 10000, icon: '💎' },
  { id: 'd4', amount: 140, bonus: 25, price: 20000, icon: '💎💎' },
  { id: 'd5', amount: 355, bonus: 70, price: 50000, icon: '💎💎' },
  { id: 'd6', amount: 720, bonus: 150, price: 100000, icon: '💎💎💎' },
  { id: 'd7', amount: 1440, bonus: 300, price: 200000, icon: '💍' },
  { id: 'd8', amount: 7290, bonus: 1500, price: 1000000, icon: '👑' },
];

export const PAYMENT_METHODS: PaymentMethod[] = [
  { id: 'dana', name: 'DANA', logo: '💳', fee: 0 },
  { id: 'gopay', name: 'GoPay', logo: '📱', fee: 0 },
  { id: 'ovo', name: 'OVO', logo: '💜', fee: 0 },
  { id: 'shopeepay', name: 'ShopeePay', logo: '🧡', fee: 0 },
  { id: 'alfamart', name: 'Alfamart', logo: '🏪', fee: 2500 },
];

export const WEAPONS: Weapon[] = [
  { name: 'M1887', type: 'Shotgun', damage: 100, rateOfFire: 42, range: 15, image: 'https://picsum.photos/seed/m1887/400/250' },
  { name: 'MP40', type: 'SMG', damage: 48, rateOfFire: 83, range: 22, image: 'https://picsum.photos/seed/mp40/400/250' },
  { name: 'AK47', type: 'AR', damage: 61, rateOfFire: 56, range: 72, image: 'https://picsum.photos/seed/ak47/400/250' },
  { name: 'AWM', type: 'Sniper', damage: 90, rateOfFire: 27, range: 91, image: 'https://picsum.photos/seed/awm/400/250' },
];

export const CHARACTERS: Character[] = [
  { name: 'Alok', ability: 'Drop the Beat', description: 'Creates a 5m aura that increases moving speed and restores HP.', image: 'https://picsum.photos/seed/alok/300/400' },
  { name: 'Chrono', ability: 'Time Turner', description: 'Creates an impenetrable force field that blocks damage.', image: 'https://picsum.photos/seed/chrono/300/400' },
];
