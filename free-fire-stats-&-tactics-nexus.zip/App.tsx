
import React, { useState } from 'react';
import { DIAMOND_BUNDLES, PAYMENT_METHODS } from './constants';
import { DiamondBundle, PaymentMethod } from './types';

const App: React.FC = () => {
  const [playerId, setPlayerId] = useState('');
  const [selectedBundle, setSelectedBundle] = useState<DiamondBundle | null>(null);
  const [selectedPayment, setSelectedPayment] = useState<PaymentMethod | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(val);
  };

  const handleCheckout = () => {
    if (!playerId || !selectedBundle || !selectedPayment) {
      alert("Lengkapi data top up Anda!");
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      alert(`Pesanan Berhasil!\nID: ${playerId}\nItem: ${selectedBundle.amount} Diamonds\nMetode: ${selectedPayment.name}`);
      setIsProcessing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white font-sans pb-32">
      {/* Header */}
      <nav className="bg-black/60 backdrop-blur-md border-b border-white/5 px-6 py-4 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-tr from-red-600 to-orange-500 w-10 h-10 rounded-lg flex items-center justify-center font-black text-xl italic shadow-lg shadow-red-600/20">FF</div>
            <h1 className="text-2xl font-bold gaming-font italic tracking-tighter">DIAMOND HUB</h1>
          </div>
          <div className="flex gap-4">
             <button className="bg-white/5 hover:bg-white/10 px-4 py-2 rounded-lg text-xs font-bold uppercase transition">Track Order</button>
          </div>
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-6 mt-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Input Sections */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Section 1: Player Info */}
          <section className="ff-card p-6 rounded-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-red-600"></div>
            <div className="flex items-center gap-4 mb-6">
              <span className="bg-red-600 w-8 h-8 rounded-full flex items-center justify-center font-bold">1</span>
              <h2 className="text-xl font-bold uppercase gaming-font">Masukkan User ID</h2>
            </div>
            <div className="space-y-4">
              <input 
                type="text" 
                placeholder="Contoh: 12345678" 
                className="w-full bg-black/40 border border-white/10 p-4 rounded-xl focus:ring-2 focus:ring-red-600 outline-none transition"
                value={playerId}
                onChange={(e) => setPlayerId(e.target.value)}
              />
              <p className="text-xs text-gray-400">Silakan masukkan Player ID Anda. User ID dapat ditemukan di menu Profil Game.</p>
            </div>
          </section>

          {/* Section 2: Diamond Selection */}
          <section className="ff-card p-6 rounded-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-yellow-500"></div>
            <div className="flex items-center gap-4 mb-6">
              <span className="bg-yellow-500 text-black w-8 h-8 rounded-full flex items-center justify-center font-bold">2</span>
              <h2 className="text-xl font-bold uppercase gaming-font">Pilih Nominal Layanan</h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {DIAMOND_BUNDLES.map((bundle) => (
                <button
                  key={bundle.id}
                  onClick={() => setSelectedBundle(bundle)}
                  className={`relative p-4 rounded-xl border transition-all text-left overflow-hidden ${
                    selectedBundle?.id === bundle.id 
                    ? 'border-yellow-500 bg-yellow-500/10 scale-95' 
                    : 'border-white/5 bg-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="text-2xl mb-2">{bundle.icon}</div>
                  <div className="font-bold text-lg">{bundle.amount} Diamonds</div>
                  {bundle.bonus && (
                    <div className="text-[10px] text-green-400 font-bold uppercase">+ {bundle.bonus} Bonus</div>
                  )}
                  <div className="text-xs text-gray-400 mt-2">{formatCurrency(bundle.price)}</div>
                  {selectedBundle?.id === bundle.id && (
                    <div className="absolute top-2 right-2 text-yellow-500">✓</div>
                  )}
                </button>
              ))}
            </div>
          </section>

          {/* Section 3: Payment Methods */}
          <section className="ff-card p-6 rounded-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-blue-500"></div>
            <div className="flex items-center gap-4 mb-6">
              <span className="bg-blue-500 w-8 h-8 rounded-full flex items-center justify-center font-bold">3</span>
              <h2 className="text-xl font-bold uppercase gaming-font">Pilih Metode Pembayaran</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {PAYMENT_METHODS.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setSelectedPayment(method)}
                  className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                    selectedPayment?.id === method.id 
                    ? 'border-blue-500 bg-blue-500/10' 
                    : 'border-white/5 bg-white/5 hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl grayscale group-hover:grayscale-0">{method.logo}</span>
                    <span className="font-bold">{method.name}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-bold text-white">
                      {selectedBundle ? formatCurrency(selectedBundle.price + method.fee) : '-'}
                    </div>
                    {method.fee > 0 && <div className="text-[9px] text-gray-500">Fee: {formatCurrency(method.fee)}</div>}
                  </div>
                </button>
              ))}
            </div>
          </section>
        </div>

        {/* Right: Summary Panel */}
        <div className="space-y-6">
          <div className="ff-card p-6 rounded-2xl sticky top-24 border-t-4 border-red-600">
            <h3 className="text-xl font-bold uppercase gaming-font mb-6 border-b border-white/5 pb-4 italic">Ringkasan Pesanan</h3>
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Item:</span>
                <span className="font-bold">{selectedBundle ? `${selectedBundle.amount} Diamonds` : 'Belum dipilih'}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Metode:</span>
                <span className="font-bold">{selectedPayment ? selectedPayment.name : 'Belum dipilih'}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">User ID:</span>
                <span className="font-bold text-yellow-500">{playerId || 'Wajib diisi'}</span>
              </div>
              <div className="pt-4 border-t border-white/5 flex justify-between items-center">
                <span className="text-lg font-bold">Total:</span>
                <span className="text-2xl font-black text-red-500">
                  {selectedBundle ? formatCurrency(selectedBundle.price + (selectedPayment?.fee || 0)) : 'Rp 0'}
                </span>
              </div>
            </div>
            
            <button 
              onClick={handleCheckout}
              disabled={isProcessing}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-red-600 to-orange-500 font-black text-lg uppercase tracking-wider hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50 shadow-lg shadow-red-600/30"
            >
              {isProcessing ? 'Sistem Sedang Memproses...' : 'Beli Sekarang'}
            </button>
            <p className="text-[10px] text-center text-gray-500 mt-4 uppercase font-bold tracking-widest">Aman • Instan • Terpercaya</p>
          </div>

          <div className="ff-card p-4 rounded-2xl text-xs text-gray-400 leading-relaxed">
            <h4 className="font-bold text-white mb-2 uppercase tracking-tighter">Butuh Bantuan?</h4>
            Punya masalah dengan top up? Hubungi Customer Service kami 24/7 melalui pusat bantuan di bawah game.
          </div>
        </div>
      </main>

      {/* Footer Branding */}
      <footer className="mt-20 border-t border-white/5 py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
             <div className="flex items-center gap-2 mb-4 justify-center md:justify-start">
               <div className="w-6 h-6 bg-red-600 rounded"></div>
               <span className="font-bold text-xl gaming-font italic">DIAMOND HUB</span>
             </div>
             <p className="text-sm text-gray-500 max-w-sm">Mitra top-up Free Fire resmi dan terpercaya di Indonesia. Diamond masuk instan hitungan detik.</p>
          </div>
          <div className="flex gap-6 grayscale opacity-40">
            {/* Mock Payment Partners */}
            <div className="w-12 h-6 bg-white/20 rounded"></div>
            <div className="w-12 h-6 bg-white/20 rounded"></div>
            <div className="w-12 h-6 bg-white/20 rounded"></div>
            <div className="w-12 h-6 bg-white/20 rounded"></div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
