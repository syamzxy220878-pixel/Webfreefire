
import React from 'react';
import { Weapon } from '../types';

interface WeaponCardProps {
  weapon: Weapon;
}

const WeaponCard: React.FC<WeaponCardProps> = ({ weapon }) => {
  return (
    <div className="ff-card rounded-xl overflow-hidden group hover:scale-[1.02] transition-transform duration-300">
      <img src={weapon.image} alt={weapon.name} className="w-full h-40 object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold text-yellow-500 gaming-font uppercase">{weapon.name}</h3>
          <span className="bg-red-600/20 text-red-500 px-2 py-0.5 rounded text-xs border border-red-500/30">{weapon.type}</span>
        </div>
        <div className="space-y-3">
          <StatBar label="Damage" value={weapon.damage} />
          <StatBar label="Fire Rate" value={weapon.rateOfFire} />
          <StatBar label="Range" value={weapon.range} />
        </div>
      </div>
    </div>
  );
};

const StatBar = ({ label, value }: { label: string; value: number }) => (
  <div className="space-y-1">
    <div className="flex justify-between text-xs text-gray-400">
      <span>{label}</span>
      <span>{value}</span>
    </div>
    <div className="w-full h-1.5 bg-gray-700 rounded-full overflow-hidden">
      <div 
        className="h-full bg-gradient-to-r from-red-500 to-orange-400 rounded-full" 
        style={{ width: `${value}%` }}
      />
    </div>
  </div>
);

export default WeaponCard;
