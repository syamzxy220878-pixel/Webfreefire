
import { GoogleGenAI } from "@google/genai";

export const getTacticalAdvice = async (weapon: string, character: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are a professional Free Fire coach. Provide a short, aggressive tactical strategy (max 100 words) using ${weapon} and ${character}. Use gaming terminology like 'rush', 'third-party', 'clutch'.`,
      config: {
        temperature: 0.8,
      },
    });
    return response.text || "Keep moving, stay sharp, and aim for the head!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error getting tactical intel. Stay aggressive regardless!";
  }
};
